#include "Usuario.h"

Usuario::Usuario()