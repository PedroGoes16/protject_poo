#include "Usuario.h"

#ifndef ADMINISTRADOR
#define ADMINISTRADOR

class Administrador{
    
    public:
    void adicionarUsuario(Usuario);
};

#endif
